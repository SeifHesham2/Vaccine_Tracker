#include "User.h"
#include <iostream>
#include <string>
#include <unordered_map>
using namespace std;

User::User(string name, string country, string governorate, long long ID, string password, char gender, short int age, bool vaccinated, bool dose1, bool dose2)
{
	this->name = name;
	this->country = country;
	this->governorate = governorate;
	this->ID = ID;
	this->password = password;
	this->gender = gender;
	this->age = age;
	this->vaccinated = vaccinated;
	this->dose1 = dose1;
	this->dose2 = dose2;
}

//Setters and getters

void User::setName(string NAME)
{
	name = NAME;
}
string User::getName()
{
	return name;
}

void User::setPassword(string PASSWORD)
{
	password = PASSWORD;
}
string User::getPassword()
{
	return password;
}

void User::setCountry(string COUNTRY)
{
	country = COUNTRY;
}
string User::getCountry()
{
	return country;
}

void User::setGovernorate(string GOVERNORATE)
{
	governorate = GOVERNORATE;
}
string User::getGovernorate()
{
	return governorate;
}

void User::setID(long long id)
{
	ID = id;
}
long long User::getID()
{
	return ID;
}

void User::setAge(short int AGE)
{
	age = AGE;
}
int User::getAge()
{
	return age;
}

void User::setGender(char GENDER)
{
	gender = GENDER;
}
char User::getGender()
{
	return gender;
}

void User::setVaccinated(bool VACCINATED)
{
	vaccinated = VACCINATED;
}
bool User::getVaccinated()
{
	return vaccinated;
}

void User::setDose1(bool DOSE1)
{
	dose1 = DOSE1;
}
bool User::getDose1()
{
	return dose1;
}

void User::setDose2(bool DOSE2)
{
	dose2 = DOSE2;
}
bool User::getDose2()
{
	return dose2;
}