#include "System.h"
#include <iostream>
using namespace std;

int main()
{
	system("color 0b");
	System s;
	s.Welcome();
	s.Display(30108040104879, "Zahran123");
	return 0;
}