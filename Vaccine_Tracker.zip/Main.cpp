#include "System.h"
#include <iostream>
using namespace std;

int main()
{
	System s;
	s.Insert();
	long long ID;
	cout << "Enter your ID: ";
	cin >> ID;
	string password;
	cout << "Enter your password: ";
	cin >> password;
	s.Display(ID, password);
	return 0;
}