#include "User.h"
#include <iostream>
using namespace std;

class System
{
public:
	void Insert(User u);
	void Display(int ID, string password);
	void EditInfo();
	void Delete();
};