#include "User.h"
using namespace std;

class System
{
public:

	void Insert();
	void Display(long long ID, string password);
	/*void EditInfo();
	void Delete();*/
};