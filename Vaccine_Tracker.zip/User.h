#include <iostream>
#include <string>
using namespace std;

class User
{
private:
	string name, password, country, governorate;
	long long ID;
	short int age;
	char gender; //M for male, F for female
	bool vaccinated; // True for vaccinated | False for not
	bool dose1; bool dose2; 
	//int first, second, male, female; (Counters for percentages)

public:
	//Constructors
	User();

	User(string name, string country, string governorate, long long ID, string password, char gender, short int age, bool vaccinated, bool dose1, bool dose2);

	//Setters and getters
	void setName(string NAME);
	string getName();

	void setPassword(string PASSWORD);
	string getPassword();

	void setCountry(string COUNTRY);
	string getCountry();

	void setGovernorate(string GOVERNORATE);
	string getGovernorate();

	void setID(long long id);
	long long getID();

	void setAge(short int AGE);
	short int getAge();

	void setGender(char GENDER);
	char getGender();

	void setVaccinated(bool VACCINATED);
	bool getVaccinated();

	void setDose1(bool DOSE1);
	bool getDose1();
	void setDose2(bool DOSE2);
	bool getDose2();
};