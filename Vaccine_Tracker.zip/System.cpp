#include "System.h"
#include "User.h"
#include "WaitingList.h"
#include <iostream>
#include <unordered_map>
#include <cctype>
using namespace std;

unordered_map<long long, User> map;
//WaitingList<User> queue;

void System::Insert(User u)
{
	cout << "Enter your name: ";
	string name;
	cin.ignore();
	getline(cin, name);

	cout << "Enter your country: ";
	string country;
	cin.ignore();
	getline(cin, country);

	cout << "Enter your governorate: ";
	string governorate;
	cin.ignore();
	getline(cin, governorate);

	cout << "Enter your national ID: ";
	long long ID;
	string k;
	do
	{
		cin >> ID;
		k = to_string(ID);
		if (k.size() != 14)
			cout << "Wrong national ID, enter your correct national ID: ";
	} while (k.size() != 14);

	cout << "Enter your password: ";
	string password;
	do
	{
		cin >> password;
		if (password.size() < 8)
			cout << "Password too small, try again: ";
	} while (password.size() < 8);

	cout << "Enter your gender (M / F): ";
	char gender;
	do
	{
		cin >> gender;
		gender = tolower(gender);
		if (gender != 'm' || gender != 'f')
			cout << "Wrong entry, try again: ";
	} while (gender != 'm' || gender != 'f');

	cout << "Enter your age: ";
	short int age; cin >> age;

	cout << "Are you vaccinated? (Y / N) ";
	char c;
	bool vaccinated;
	do
	{
		cin >> c;
		c = tolower(c);
		if (c != 'y' || c != 'n')
			cout << "Wrong entry, try again: ";
		else
		{
			if (c == 'y')
			{
				vaccinated = true;
				cout << "How many doses have you taken? (1 / 2) ";
				short int c;
				do
				{
					cin >> c;
					if (c != 1 || c != 2)
						cout << "Wrong number, try again: ";
				} while(c != 1 || c != 2);
				
				if (c == 1)
				{
					u = User(name, country, governorate, ID, password, gender, age, vaccinated, true, false);
				}
				else
				{
					u = User(name, country, governorate, ID, password, gender, age, vaccinated, true, true);
				}
			}
			else
			{
				vaccinated = false;
				u = User(name, country, governorate, ID, password, gender, age, vaccinated, false, false);
			}
		}
	} while (vaccinated == NULL);
}