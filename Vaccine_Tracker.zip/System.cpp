#include "System.h"
#include "WaitingList.cpp"
#include <iostream>
#include <unordered_map>
#include <cctype>
#include <conio.h>
#include <string.h>
using namespace std;

unordered_map<long long, User> map;
WaitingList<User> queue;

void System::Insert()
{
	cout << "Enter your name: ";
	string name;
	cin.ignore();
	getline(cin, name);

	cout << "Enter your country: ";
	string country;
	getline(cin, country);

	cout << "Enter your governorate: ";
	string governorate;
	getline(cin, governorate);

	cout << "Enter your national ID: ";
	long long ID;
	string k;
	do
	{
		cin >> ID;
		k = to_string(ID);
		if (k.size() != 14)
			cout << "Wrong national ID, enter your correct national ID: ";
	} while (k.size() != 14);

	cout << "Enter your password: ";
	string password;
	do
	{
		cin >> password;
		if (password.size() < 8)
			cout << "Password too small, try again: ";
	} while (password.size() < 8);

	cout << "Enter your gender (M / F): ";
	char gender;
	do
	{
		cin >> gender;
		gender = tolower(gender);
		if (gender != 'm' && gender != 'f')
			cout << "Wrong entry, try again: ";
	} while (gender != 'm' && gender != 'f');

	cout << "Enter your age: ";
	short int age; cin >> age;

	cout << "Are you vaccinated? (Y / N) ";
	char c;
	bool vaccinated = NULL;
	do
	{
		cin >> c;
		c = tolower(c);
		if (c != 'y' && c != 'n')
			cout << "Wrong entry, try again: ";
		else
		{
			if (c == 'y')
			{
				vaccinated = true;
				cout << "How many doses have you taken? (1 / 2) ";
				short int c;
				do
				{
					cin >> c;
					if (c != 1 && c != 2)
						cout << "Wrong number, try again: ";
				} while (c != 1 && c != 2);

				if (c == 1)
				{
					User u(name, country, governorate, ID, password, gender, age, vaccinated, true, false);
					map[ID] = u;
				}
				else
				{
					User u(name, country, governorate, ID, password, gender, age, vaccinated, true, true);
					map[ID] = u;
				}
			}

			else
			{
				vaccinated = false;
				User u(name, country, governorate, ID, password, gender, age, vaccinated, false, false);
				
				queue.enqueue(u);

				map[ID] = u;
			}
		}
	} while (vaccinated != true && vaccinated != false);
}

void System::Display(long long ID, string password)
{
	cout << "Name: " << map.at(ID).getName() << endl;
	cout << "Country: " << map.at(ID).getCountry() << endl;
	cout << "Governorate: " << map.at(ID).getGovernorate() << endl;
	cout << "ID: " << map.at(ID).getID() << endl;
	cout << "Password: " << map.at(ID).getPassword() << endl;

	string gender = (map.at(ID).getGender() == 'm') ? "Male" : "Female";
	cout << "Gender: " << gender << endl;

	cout << "Age: " << map.at(ID).getAge() << endl;

	string vaccinated = (map.at(ID).getVaccinated()) ? "Yes" : "No";
	cout << "Vaccinated: " << vaccinated << endl;
	
	if (map.at(ID).getVaccinated())
	{
		char dose = (map.at(ID).getDose2()) ? '2' : '1';
		cout << "Doses: " << dose << endl;
	}

	Login();
}


//MAINTAINED

void System::Login()
{
	string Name;
	string ch;
	string x[20];
	int attempts = 0;
	bool verified = 0;
	string password = map.at(30108040104879).getPassword();

	cout << "\nName: "; cin >> Name;
	do
	{
		attempts++;
		int c = 0; //Counter for: if the entered character equals to a character in the same place of the saved password in declaration
		int i = -1;
		int m = 0; //Counter for: counting the number of characters in the saved password in the declaration
		int a = 0; //Counter for: counting the number of the entered characters
		cout << "Password: ";
		ch = _getch(); //Works like cin, but _getch() enters character by character
		a++;
		i = i + 1;
		x[i] = ch;
		//If the entered character equals to the character in the same place of the saved password in declaration
		char z[20];
		strcpy_s(z, x[i].c_str());
		if (z[i] == password.at(i))
			c++;
		while (ch != "\r") //While not pressed on the enter (not finished typing the password)
		{
			i = i + 1;
			cout << "*"; //To make the password entered in asterisks ( ******** )
			ch = _getch();
			if (ch == "\r")
				break;
			a++;
			x[i] = ch;
			strcpy_s(z, x[i].c_str());
			if (z[0] == password.at(i))
				c++;
		}
		
		m = password.size();
		//If c (number of correct entered characters) = a - 1 (number of entered characters) then login successfully
		//a - 1 because pressing on 'enter' increases the (a) counter by 1
		/*
		* For example: the saved password is 12345678
		* If i entered 12345678999
		* The number of correct characters and their order equal to the saved password, but the whole entered characters not equal to the saved password.
		*/
		if (c == a && c == m)
		{
			verified = 1;
			cout << "\nLogin successfully!" << endl;
			break;
		}
		else
		{
			if (attempts == 1)
				cout << "\nWrong password.\nYou have 2 tries left\n";
			else if (attempts == 2)
				cout << "\nWrong password.\nYou have 1 try left\n";
			else
				break;
		}
	} while (attempts <= 3);
	//If not logged in successfully
	if (!verified)
		cout << "\nLogin failed, please try again later." << endl;
}

void System::Welcome()
{
	cout << "\t\t\t\t\tWelcome to Vaccine Tracker System!\n\n";
	cout << "Choose one of the following options:\n";
	cout << "1) User Registeration\t\t\t\t2) User Login\t\t\t\t3) Admin Login\n";
	char c;
	do
	{
		cin >> c;
		if (c != '1' && c != '2' && c != '3')
			cout << "Wrong entry, try again.\n";
	} while (c != '1' && c != '2' && c != '3');
	switch (c)
	{
	case '1': Insert();
		break;
	case '2': Login();
		break;
	default:
		break;
	}
}