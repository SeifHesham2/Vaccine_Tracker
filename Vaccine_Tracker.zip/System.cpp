#include "System.h"
#include "WaitingList.cpp"
#include <iostream>
#include <unordered_map>
#include <cctype>
using namespace std;

unordered_map<long long, User> map;
WaitingList<User> queue;

void System::Insert()
{
	cout << "Enter your name: ";
	string name;
	getline(cin, name);

	cout << "Enter your country: ";
	string country;
	getline(cin, country);

	cout << "Enter your governorate: ";
	string governorate;
	getline(cin, governorate);

	cout << "Enter your national ID: ";
	long long ID;
	string k;
	do
	{
		cin >> ID;
		k = to_string(ID);
		if (k.size() != 14)
			cout << "Wrong national ID, enter your correct national ID: ";
	} while (k.size() != 14);

	cout << "Enter your password: ";
	string password;
	do
	{
		cin >> password;
		if (password.size() < 8)
			cout << "Password too small, try again: ";
	} while (password.size() < 8);

	cout << "Enter your gender (M / F): ";
	char gender;
	do
	{
		cin >> gender;
		gender = tolower(gender);
		if (gender != 'm' && gender != 'f')
			cout << "Wrong entry, try again: ";
	} while (gender != 'm' && gender != 'f');

	cout << "Enter your age: ";
	short int age; cin >> age;

	cout << "Are you vaccinated? (Y / N) ";
	char c;
	bool vaccinated = NULL;
	do
	{
		cin >> c;
		c = tolower(c);
		if (c != 'y' && c != 'n')
			cout << "Wrong entry, try again: ";
		else
		{
			if (c == 'y')
			{
				vaccinated = true;
				cout << "How many doses have you taken? (1 / 2) ";
				short int c;
				do
				{
					cin >> c;
					if (c != 1 && c != 2)
						cout << "Wrong number, try again: ";
				} while (c != 1 && c != 2);

				if (c == 1)
				{
					User u(name, country, governorate, ID, password, gender, age, vaccinated, true, false);
					map[ID] = u;
				}
				else
				{
					User u(name, country, governorate, ID, password, gender, age, vaccinated, true, true);
					map[ID] = u;
				}
			}

			else
			{
				vaccinated = false;
				User u(name, country, governorate, ID, password, gender, age, vaccinated, false, false);
				
				queue.enqueue(u);

				map[ID] = u;
			}
		}
	} while (vaccinated != true && vaccinated != false);
}

void System::Display(long long ID, string password)
{
	cout << "Name: " << map.at(ID).getName() << endl;
	cout << "Country: " << map.at(ID).getCountry() << endl;
	cout << "Governorate: " << map.at(ID).getGovernorate() << endl;
	cout << "ID: " << map.at(ID).getID() << endl;
	cout << "Password: " << map.at(ID).getPassword() << endl;
	
	string gender = (map.at(ID).getGender() == 'm') ? "Male" : "Female";
	cout << "Gender: " << gender << endl;

	cout << "Age: " << map.at(ID).getAge() << endl;

	string vaccinated = (map.at(ID).getVaccinated()) ? "Yes" : "No";
	cout << "Vaccinated: " << vaccinated << endl;
	
	if (map.at(ID).getVaccinated())
	{
		char dose = (map.at(ID).getDose2()) ? '2' : '1';
		cout << "Doses: " << dose << endl;
	}
}