#pragma once
#include<iostream>
#include<fstream>
#include<sstream>
#include<cstring>
#include<vector>
#include<set>
#include<string>
#include<cstring>
#include <mutex>
#include<queue>
#include <fstream>
#include<unordered_map>
#include"User.h"
using namespace std;
class System
{
private:
	string currentuser;
	set<User>myset;
	unordered_map<string, User> umap;
	queue<User>waitingList;

public:
	

	System();
	~System();
	void open();
	void Add(User);
	void Read();
	void Write();
	void DisAllDataInSystem();
	void DisAllDataInWaitingList();
	void DisUserData(string nationalId);
	void SignAdmin();
	void SignUser();
	void RegisterUser();
	void ListOfUser();
	void ChoiceListOfUser(string choice);
	void ListOfAdmin();
	void Save();
	void EditData(string choice);
	void CloseTheProgram();
	int NumberOfMales();
	int NumberOfPeopleOver25();
	void addUsersAuto(int x);
	

	//void ViewAllUsers();
	//bool CheckAdmin(string nationalId);
};

