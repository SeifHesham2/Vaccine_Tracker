#include "User.h"
#include<string>
#include<cstring>
int User::counter = 0;
int User::maleCounter = 0;
int User::femaleCounter = 0;

User::User(string nationalId, string password, string fullName, string age, string gender, string country, string governorate)
{
	this->nationalId = nationalId;
	this->password = password;
	this->age = age;
	this->gender = gender;
	this->country = country;
	this->governorate = governorate;
	this->fullName = fullName;
	this->firstDose = false;
	this->secondDose = false;
	this->vaccinated = false;
	this->admin = false;
	counter++;
	if (gender == "Male")
		maleCounter++;
	else if (gender == "Female")
		femaleCounter++;
}

User::User(string nationalId, string password, string fullName)
{
	this->nationalId = nationalId;
	this->password = password;
	this->fullName = fullName;
}

User::User(string nationalId)
{
	this->nationalId = nationalId;
}

User::User()
{
}



User::~User()
{
	counter--;
}

void User::DisplayData()
{
	//cout << "id\t\tname\t\t\t\tage\tgender\tcountry\tgovernorate\vaccinated\tfirst dose\tsecond doset\n";

	//cout << nationalId << "\t" << fullName << "\t" << age << "\t" << gender << "\t" << country << "\t" << governorate << "\t\t" <<vaccinated<<"\t"<< firstDose << "\t" << secondDose << endl;
	cout << nationalId << endl << fullName << endl << age << endl << gender << endl << country << endl << governorate << endl;
	cout << "-------------------------\n";
}
bool User::GetFirstDose()
{
	return firstDose;
}
bool User::GetSecondDose()
{
	return secondDose;
}
string User::GetNationalId()
{
	return nationalId;
}

string User::GetPassword()
{
	return password;
}

string User::GetFullName()
{
	return fullName;
}

string User::GetCountry()
{
	return country;
}

string User::GetGovernorate()
{
	return governorate;
}

string User::GetAge()
{
	return age;
}

string User::GetGender()
{
	return gender;
}




void User::SetNationalId(string nationalId)
{
	this->nationalId = nationalId;
}

void User::SetName(string name)
{
	this->fullName = name;
}

void User::SetPassword(string password)
{
	this->password = password;
}

void User::SetGender(string gender)
{
	this->gender = gender;
}

void User::SetGovernorate(string governorate)
{
	this->governorate = governorate;
}

void User::SetCountry(string Country)
{
	this->country = country;
}

void User::SetAge(string age)
{
	this->age = age;
}

void User::SetFirstDose(bool firstDose)
{
	this->vaccinated = firstDose;
	this->firstDose = firstDose;
	
}

void User::SetSecondDose(bool secondDose)
{
	this->secondDose = secondDose;
}

void User::SetAdmin(bool admin)
{
	this->admin = admin;
}



bool User::GetAdmin()
{
	return admin;
}


void User::Edit()
{
	cout << "what you want to edit?\n1-National Id\n2-Name\n3-password\n4-age\n5-Gender\n6-Governorate\n7-All\n";
	int choice;
	cin >> choice;
	switch (choice)
	{
	case 1:
	{
		string nationalId;
		cout << "Enter National Id: ";
		cin >> nationalId;
		SetNationalId(nationalId);
		
	}
	break;
	case 2:
	{
		string name;
		cout << "Enter Your Name: ";
		cin.ignore();
		getline(cin, name);
		SetName(name);
	}
	break;
	case 3:
	{
		string password;
		cout << "Enter The Password: ";
		cin >> password;
		SetPassword(password);
	}
	break;
	case 4:
	{
		string age;
		cout << "Enter the Age: ";
		cin >> age;
		SetAge(age);
	}
	break;
	case 5:
	{
		string gender;
		cout << "Enter The Gender: ";
		cin >> gender;
		SetGender(gender);
	}
	break;
	case 6:
	{
		string governorate;
		cout << "Enter The Governorate: ";
		cin.ignore();
		getline(cin, governorate);
		SetGovernorate(governorate);
	}
	break;
	case 7:
	{
		string nationalId;
		string name;
		string password;
		string age;
		string gender;
		string governorate;

		cout << "Enter National Id: ";
		cin >> nationalId;
		SetNationalId(nationalId);
		cout << "Enter Your Name: ";
		cin.ignore();
		getline(cin, name);
		SetName(name);
		cout << "Enter The Password: ";
		cin >> password;
		SetPassword(password);
		cout << "Enter the Age: ";
		cin >> age;
		SetAge(age);
		cout << "Enter The Gender: ";
		cin >> gender;
		SetGender(gender);
		cout << "Enter The Governorate: ";
		cin.ignore();
		getline(cin, governorate);
		SetGovernorate(governorate);
		
	}
	break;
	default:
		cout << "Wrong Choice\n";
		break;
	}
}



