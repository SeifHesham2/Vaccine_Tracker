#include<iostream>
#include<fstream>
#include<sstream>
#include<cstring>
#include<vector>
#include<set>
#include<string>
#include<cstring>
#include <mutex>
#include <fstream>
#include<unordered_map>
#include<map>
#include<Windows.h>
#include<random>
#include"User.h"
using namespace std;
vector<string>vec;
std::mutex logMutex;
#include "System.h"

System::System()
{
	
	Read();
	//addUsersAutoInMainData();
	//addUsersAutoInWaitingList();
	//addUsersAuto(0);
	/*for (auto i : umap)
	{
		i.second.DisplayData();
	}
	Sleep(20000);*/
	//Write();
	open();
}

System::~System()
{
	Write();
	
}

void System::open()
{
	system("cls");
	cout << "1-Login As Admin\n2-Login As User\n3-Regestration\n4-Close The Program\n";
	string choice;
	cout << "Enter Your Choice :";
	cin >> choice;
	if (choice == "1")
	{
		SignAdmin();

	}
	else if (choice == "2")
	{
		SignUser();
	}
	else if (choice == "3")
	{
		RegisterUser();
	}
	else if (choice == "4")
	{
		CloseTheProgram();
	}
	else
	{
		cout << "Your Choice Is Wrong Please Try Again;)\n";
		Sleep(2000);
		open();
	}

}

void System::Add(User new_user)
{
	umap[new_user.GetNationalId()] = new_user;
	
}

void System::Read()
{
	vector<vector<string>> content;
	vector<string> row;
	string line, word;

	fstream file("data.csv", ios::in);
	if (file.is_open())
	{
		while (getline(file, line))
		{
			row.clear();

			stringstream str(line);

			while (getline(str, word, ','))
				row.push_back(word);
			content.push_back(row);
		}
	}
	else
		cout << "Could not open the file\n";

	for (int i = 0; i < content.size(); i++)
	{

		User h(content[i][0], content[i][1], content[i][2], content[i][3], content[i][4], content[i][5], content[i][6]);
		if (content[i][8] == "1")
			h.SetFirstDose(true);
		if (content[i][9] == "1")
			h.SetSecondDose(true);
		if (content[i][10] == "1")
			h.SetAdmin(true);
		umap [h.GetNationalId()]= h;

	}
	file.close();



	vector<vector<string>> content1;
	vector<string> row1;
	string line1, word1;

	fstream file1("waitinglist.csv", ios::in);
	if (file1.is_open())
	{
		while (getline(file1, line1))
		{
			row1.clear();

			stringstream str(line1);

			while (getline(str, word1, ','))
				row1.push_back(word1);
			content1.push_back(row1);
		}
	}
	else
		cout << "Could not open the file\n";

	for (int i = 0; i < content1.size(); i++)
	{

		User h(content1[i][0], content1[i][1], content1[i][2], content1[i][3], content1[i][4], content1[i][5], content1[i][6]);
		if (content1[i][8] == "1")
			h.SetFirstDose(true);
		if (content1[i][9] == "1")
			h.SetSecondDose(true);
		if (content1[i][10] == "1")
			h.SetAdmin(true);
		waitingList.push(h);

	}
	file1.close();
}

void System::Write()
{
	//cout << umap.size() << endl;
	// file pointer
	fstream file;
	// opens an existing csv file or creates a new file.
	file.open("data.csv", ios::out | ios::trunc);
	for (auto i : umap)
	{
		//cout << "a\n";
		



		file << i.second.GetNationalId() << ","
			<< i.second.GetPassword() << ","
			<< i.second.GetFullName() << ","
			<< i.second.GetAge() << ","
			<< i.second.GetGender() << ","
			<< i.second.GetCountry() << ","
			<< i.second.GetGovernorate() << ","
			<< i.second.GetFirstDose() << ","
			<< i.second.GetFirstDose() << ","
			<< i.second.GetSecondDose() << ","
			<< i.second.GetAdmin()
			<< "\n";
	}
	file.close();


	fstream file1;
	// opens an existing csv file or creates a new file.
	file1.open("waitinglist.csv", ios::out | ios::trunc);
	
	while(!waitingList.empty())
	{//cout << "a\n";




		file1 << waitingList.front().GetNationalId() << ","
			<< waitingList.front().GetPassword() << ","
			<< waitingList.front().GetFullName() << ","
			<< waitingList.front().GetAge() << ","
			<< waitingList.front().GetGender() << ","
			<< waitingList.front().GetCountry() << ","
			<< waitingList.front().GetGovernorate() << ","
			<< waitingList.front().GetFirstDose() << ","
			<< waitingList.front().GetFirstDose() << ","
			<< waitingList.front().GetSecondDose() << ","
			<< waitingList.front().GetAdmin()
			<< "\n";
		waitingList.pop();
	}
	file1.close();
}

void System::DisAllDataInSystem()
{
	system("cls");
	cout << "Data of All Users\n------------------\n";
	cout << umap.size() << endl;
	for (auto i : umap)
		DisUserData(i.second.GetNationalId());
}

void System::DisAllDataInWaitingList()
{
	system("cls");
	cout << "Data of All Users In Waiting List\n------------------\n";
	cout << waitingList.size() << endl;
	queue<User>q;
	while (!waitingList.empty())
	{
		cout << "National Id : " << waitingList.front().GetNationalId() << endl;
		cout << "Full Nam : " << waitingList.front().GetFullName() << endl;
		cout << "Gender : " << waitingList.front().GetGender() << endl;
		cout << "Country : " << waitingList.front().GetCountry() << endl;
		cout << "Governorate : " << waitingList.front().GetGovernorate() << endl;
		cout << "Age : " << waitingList.front().GetAge() << endl;
		int n = 0;
		if (waitingList.front().GetFirstDose() == true && waitingList.front().GetSecondDose() == true)
			n = 2;
		else if (waitingList.front().GetFirstDose() == true || waitingList.front().GetSecondDose() == true)
			n = 1;
		cout << "Number Of Doses :" << n << endl;
		cout << "-----------------------------\n";
		q.push(waitingList.front());
		waitingList.pop();
	}
	waitingList = q;
}

void System::DisUserData(string nationalId)
{
	
	cout << "National Id : " << umap[nationalId].GetNationalId() << endl;
	cout << "Full Nam : " << umap[nationalId].GetFullName() << endl;
	cout << "Gender : " << umap[nationalId].GetGender() << endl;
	cout << "Country : " << umap[nationalId].GetCountry() << endl;
	cout << "Governorate : " << umap[nationalId].GetGovernorate() << endl;
	cout << "Age : " << umap[nationalId].GetAge() << endl;
	int n = 0;
	if (umap[nationalId].GetFirstDose() == true && umap[nationalId].GetSecondDose() == true)
		n = 2;
	else if (umap[nationalId].GetFirstDose() == true || umap[nationalId].GetSecondDose() == true)
		n = 1;
	cout << "Number Of Doses :" << n << endl;
	cout << "-----------------------------\n";
}

void System::SignAdmin()
{
	system("cls");
	string username, password;
	cout << "enter the National Id:"; cin >> username;
	cout << "enter the password:"; cin >> password;
	auto i = umap.find(username);
	/*if (i != umap.end())
	{
		cout << "1\n";
		if (i->second.admin == 1)
			cout << "2\n";
	}
	if (password == "88888888")
		cout << "3\n";*/
	
	if (i != umap.end()&&i->second.GetAdmin()==1&&password=="88888888")
	{
		currentuser = username;
		ListOfAdmin();

	}
	else
	{
		if (i == umap.end())
			cout << "The National Id isn't correct\n";
		else if (i->second.GetAdmin() == 0)
			cout << "You aren't Admin\n";
		else
			cout << "The Password isn't correct\n";
		string choice;
		cout << "1-sign again\n2-back\nEnter Your Choice:";
		cin >> choice;
		while (choice != "1" && choice != "2")
		{
			cout << "Your Choice Is Wrong Please Try Again;)\n";
			Sleep(2000);
			cout << "1-sign again\n2-back\nEnter Your Choice:";
			cin >> choice;
		}
		if (choice == "1")
		{
			SignAdmin();
		}
		else if(choice =="2")
			open();
		
	}

}

void System::SignUser()
{
	system("cls");
	string username, password;
	cout << "Enter The National Id:"; cin >> username;
	cout << "Enter The Password:"; cin >> password;
	auto i = umap.find(username);
	/*if (i != umap.end())
	{
		cout << "1\n";
		if (i->second.admin == 1)
			cout << "2\n";
	}
	if (password == "88888888")
		cout << "3\n";*/

	if (i != umap.end() && i->second.GetPassword() == password)
	{
		currentuser = username;
		ListOfUser();


	}
	else
	{
		if (i == umap.end())
			cout << "The National Id isn't correct \n";
		else
			cout << "The Password isn't correct \n";
		string choice;
		cout << "1-sign again\n2-back\nEnter Your Choice:";
		cin >> choice;
		while (choice != "1" && choice != "2")
		{
			cout << "Your Choice Is Wrong Please Try Again;)\n";
			Sleep(2000);
			cout << "1-sign again\n2-back\nEnter Your Choice:";
			cin >> choice;
		}
		if (choice == "1")
		{
			SignUser();
		}
		else if (choice == "2")
			open();
	}
}

void System::RegisterUser()
{
	system("cls");
	cout << "Regestration\n";
	cout << "-------------\n";
	string nationalId, password, age, finame,sename,thname,foname, gender, country, governorate,fullName;
	cout << "Enter the NattionalId:"; cin >> nationalId;
	auto i = umap.find(nationalId);
	if (i == umap.end())
	{
		cout << "Enter Your First Name:"; cin >> finame;
		cout << "Enter Your Second Name:";  cin >> sename;
		cout << "Enter Your Third Name:"; cin >> thname;
		cout << "Enter Your Fourth Name:";  cin >> foname;
		cout << "Enter Your Password:"; cin >> password;
		cout << "Enter Your Age:"; cin >> age;
		cout << "Enter Your Gender:"; cin >> gender;
		cout << "Enter Your Country:"; cin >> country;
		cout << "Enter Your Governorate:"; cin >> governorate;
		fullName = finame + " " + sename + " " + thname + " " + foname;
		User u(nationalId, password, fullName, age, gender, country, governorate);
		Add(u);
		cout << "The Registration is Done\n";
		//Save();
		Sleep(2000);
	}
	else
	{
		cout << "this user is alreday exist\n";
		char choice;
		cout << "1-try again\n2-back\nEnter Your Choice:";
		cin >> choice;
		if (choice == '1')
		{
			RegisterUser();
		}
		
	}
	open();
}

void System::ListOfUser()
{
	system("cls");
	cout << "Welcome " << umap[currentuser].GetFullName() << endl;
	cout << "------------------------------------\n";
	cout << "1-view all of my data\n2-edit my data\n3-delete my account\n4-LogOut\n";
	string choice;
	cout << "Enter Your Choice :"; cin >> choice;
	ChoiceListOfUser(choice);
	
}

void System::ChoiceListOfUser(string choice)
{
	if (choice == "1")
	{
		system("cls");
		cout << "All Of Your Information\n";
		cout << "-----------------------------\n";
		DisUserData(currentuser);
		cout << "if you want fo another something enter y else enter another character\n";
		string choice; cin >> choice;
		if (choice == "y")
			ListOfUser();
		else
			CloseTheProgram();

	}
	else if (choice == "2")
	{
		system("cls");
		cout << "Edit Your Data\n-----------------\n";
		cout << "1-Name\n2-Password\n3-National Id\n4-Age\n5-Gender\n6-Country\n7-Governorate\n8-First Dose\n9-Second Dose\n";
		string choice;
		cout << "Enter Your Choice :"; cin >> choice;
		EditData(choice);
	}
	else if (choice == "3")
	{
		umap.erase(currentuser);
		cout << "The Peration is Done\n";
		Sleep(2000);
		Save();
		open();
	}
	else if (choice == "4")
	{
		Save();
		open();

	}
	else
	{
		cout << "Your Choice Is Wrong Please Try Again;)\n";
		Sleep(2000);
		ListOfUser();
	}
}

void System::ListOfAdmin()
{
	system("cls");
	cout << "Welcome " << umap[currentuser].GetFullName() << endl;
	cout << "------------------------------------\n";
	cout << "1-view all users in system\n2-view all users in Waiting List\n3-view statistics\n4-delete user\n5-add admin\n6-LogOut\n";
	string choice;
	cout << "Enter Your Choice :"; cin >> choice;
	if (choice == "1")
	{
		DisAllDataInSystem();
		cout << "if you want fo another something enter y else enter another character\n";
		string choice; cin >> choice;
		if (choice == "y")
			ListOfAdmin();
		else
			CloseTheProgram();

	}
	else if (choice == "2")
	{
		DisAllDataInWaitingList();
		cout << "if you want fo another something enter y else enter another character\n";
		string choice; cin >> choice;
		if (choice == "y")
			ListOfAdmin();
		else
			CloseTheProgram();
	}
	else if (choice == "3")
	{
		system("cls");
		cout << "the number of males vaccinated :" << NumberOfMales()<<endl;
		cout << "the number of females vaccinated :" << umap.size()-NumberOfMales()<<endl;
		cout << "the number of people over 25 vaccinated :" << NumberOfPeopleOver25() << endl;
		cout << "the number of people under 25 vaccinated :" << umap.size()-NumberOfPeopleOver25() << endl;
		cout << "if you want fo another something enter y else enter another character\n";
		string choice; cin >> choice;
		if (choice == "y")
			ListOfAdmin();
		else
			CloseTheProgram();


	}
	else if (choice == "4")
	{
		string nationalid;
		cout << "enter the national id :"; cin >> nationalid;
		bool flag = false;
		for(auto i:umap)
			if (i.second.GetNationalId() == nationalid)
			{
				flag = true;
				break;
			}
		if (flag)
		{
			umap.erase(nationalid);
			cout << "The Operation is Done\n";
			Sleep(2000);
			Save();
		}
		else
		{
			cout << "this user isn't exist in the system\n";
		}
		ListOfAdmin();

	}
	else if (choice == "5")
	{
		string nationalid;
		cout << "enter the national id :"; cin >> nationalid;
		bool flag = false;
		for (auto i : umap)
			if (i.second.GetNationalId() == nationalid)
			{
				flag = true;
				break;
			}
		if (flag)
		{
			umap[nationalid].SetAdmin(true);
			cout << "The Operation is Done\n";
			Sleep(2000);
			Save();
		}
		else
		{
			cout << "this user isn't exist in the system\n";
			Sleep(2000);
		}
		ListOfAdmin();
	}
	else if (choice == "6")
	{
		Save();
		open();
	}
	else
	{
		cout << "Your Choice Is Wrong Please Try Again;)\n";
		Sleep(2000);
		ListOfAdmin();
	}
}

void System::Save()
{
	Write();
	Read();
}

void System::EditData(string choice)
{
	system("cls");
	cout << "Edit Your Data\n-----------------\n";
	//1-Name\n2-Password\n3-National Id\n4-Age\n5-Gender\n6-Country\n7-Governorate\n8-First Dose\n9-Second Dose
	if (choice == "1")
	{
		string fullname, finame, sename, thname, foname;
		cout << "Enter Your First Name:"; cin >> finame;
		cout << "Enter Your Second Name:";  cin >> sename;
		cout << "Enter Your Third Name:"; cin >> thname;
		cout << "Enter Your Fourth Name:";  cin >> foname;
		fullname = finame + " " + sename + " " + thname + " " + foname;
		umap[currentuser].SetName(fullname);
		cout << "The Operation is Done\n";
		Save();
		Sleep(2000);
		ListOfUser();
	}
	else if (choice == "2")
	{
		string password;
		cout << "Enter the new password :"; cin >> password;
		umap[currentuser].SetPassword(password);
		cout << "The Operation is Done\n";
		Save();
		Sleep(2000);
		ListOfUser();
	}
	else if (choice == "3")
	{
		string nationalId;
		cout << "Enter the National Id:"; cin >> nationalId;
		bool found = false;
		for (auto i : umap)
		{
			if (i.second.GetNationalId() == nationalId)
			{
				found = true;
				break;
			}
		}
		while (found)
		{
			cout << "This National Id is Already Exist in System Please Try Again;)\n";
			Sleep(2000);
			string choice;
			cout << "if you want to try again enter y or enter another character to back\n";
			cin >> choice;
			if (choice != "y")
			{
				ListOfUser();
			}
			cout << "Enter the National Id:"; cin >> nationalId;
		}
		//User(string nationalId, string password, string fullName, string age, string gender, string country, string governorate);

		User n(nationalId,umap[currentuser].GetPassword(), umap[currentuser].GetFullName(), umap[currentuser].GetAge(), umap[currentuser].GetGender(), umap[currentuser].GetCountry(), umap[currentuser].GetGovernorate());
		if (umap[currentuser].GetFirstDose() == true)
			n.SetFirstDose(true);
		if (umap[currentuser].GetSecondDose() == true)
			n.SetSecondDose(true);
		umap.erase(currentuser);
		currentuser = n.GetNationalId();
		umap[n.GetNationalId()] = n;
		//umap[currentuser].SetNationalId(nationalId);
		cout << "The Operation is Done\n";
		Save();
		Sleep(2000);
		ListOfUser();
	}
	else if (choice == "4")
	{
		string age;
		cout << "Enter Your Age :"; cin >> age;
		umap[currentuser].SetAge(age);
		cout << "The Operation is Done\n";
		Save();
		Sleep(2000);
		ListOfUser();
	}
	else if (choice == "5")
	{
		string gender;
		cout << "Enter Your Gender :"; cin >> gender;
		umap[currentuser].SetGender(gender);
		cout << "The Operation is Done\n";
		Save();
		Sleep(2000);
		ListOfUser();
	}
	else if (choice == "6")
	{
		string country;
		cout << "Enter Your Country :"; cin >> country;
		umap[currentuser].SetCountry(country);
		cout << "The Operation is Done\n";
		Save();
		Sleep(2000);
		ListOfUser();
	}
	else if (choice == "7")
	{
		string governorate;
		cout << "Enter Your Governorate :"; cin >> governorate;
		umap[currentuser].SetGovernorate(governorate);
		cout << "The Operation is Done\n";
		Save();
		Sleep(2000);
		ListOfUser();
	}
	else if (choice == "8")
	{
		cout << "Take The first Dose?\n1-Yes\t2-No\nEnter Your choice :";
		string choice; cin >> choice;
		if (choice == "1")
		{
			umap[currentuser].SetFirstDose(true);
		}
		else if (choice == "2")
		{
			umap[currentuser].SetFirstDose(false);
		}
		cout << "The Operation is Done\n";
		Save();
		Sleep(2000);
		ListOfUser();
	}
	else if (choice == "9")
	{
		cout << "Take The second Dose?\n1-Yes\t2-No\nEnter Your choice :";
		string choice; cin >> choice;
		if (choice == "1")
		{
			umap[currentuser].SetSecondDose(true);
		}
		else if (choice == "2")
		{
			umap[currentuser].SetSecondDose(false);
		}
		cout << "The Operation is Done\n";
		Save();
		Sleep(2000);
		ListOfUser();
	}
	else 
	{
		cout << "Your Choice Is Wrong Please Try Again;)\n";
		Sleep(2000);
		ChoiceListOfUser("2");
		
	}
}

void System::CloseTheProgram()
{
	Write();
	exit(0);
}

int System::NumberOfMales()
{
	int n = 0;
	for (auto i : umap)
		if (i.second.GetGender() == "Male")
			n++;
	return n;
}

int System::NumberOfPeopleOver25()
{
	int n = 0;
	for (auto i : umap)
		if (stoi(i.second.GetAge()) >= 25)
			n++;
	return n;
}

void System::addUsersAuto(int mood)
{
	vector<string> nationalIdvector;
	vector<string>namesvector;
	vector<string>governoratevector;
	vector<string> row;
	string line, word;
	string x;

	fstream file1("nationalId.txt", ios::in);
	if (file1.is_open())
	{
		while (getline(file1, line))
		{
			//row.clear();

			stringstream str(line);

			while (getline(str, word, ','))
				x = word;
			nationalIdvector.push_back(x);
		}
	}
	else
		cout << "Could not open the file\n";
	file1.close();

	fstream file2("names.txt", ios::in);
	if (file2.is_open())
	{
		while (getline(file2, line))
		{
			//row.clear();

			stringstream str(line);

			while (getline(str, word, ','))
				x = word;
			namesvector.push_back(x);
		}
	}
	else
		cout << "Could not open the file\n";
	file2.close();


	fstream file3("governorate.txt", ios::in);
	if (file3.is_open())
	{
		while (getline(file3, line))
		{
			//row.clear();

			stringstream str(line);

			while (getline(str, word, ','))
				x = word;
			governoratevector.push_back(x);
		}
	}
	else
		cout << "Could not open the file\n";
	file3.close();

	int z = 100;
	//int size = 300;
	while (z--)
	{
		int n1, n2, n3, n4;
		int g=rand()%27;
		string id;
		n1 = rand() % 44;
		while (true)
		{
			n2 = rand() % 44;
			if (n2 != n1)
			{
				
				break;
			}
		}
		while (true)
		{
			n3 = rand() % 44;
			if (n3 != n2)
			{
				
				break;
			}
		}
		while (true)
		{
			n4 = rand() % 44;
			if (n4 != n3)
			{
				
				break;
			}
		}
		string name = namesvector[n1] + " " + namesvector[n2] + " " + namesvector[n3] + " " + namesvector[n4];
		string governorate = governoratevector[g];
		int i = rand() % nationalIdvector.size();
		string nationalId = nationalIdvector[i];
		auto it = nationalIdvector.begin() + i;
		nationalIdvector.erase(it);
		int x = rand() % 100 + 10;
		char n;
		string age = "";
		while (x)
		{
			n = x % 10 + 48;
			//cout << "n is " << n << endl;
			age += n;
			x /= 10;
		}
		reverse(age.begin(), age.end());

		//User(string nationalId, string password, string fullName, string age, string gender, string country, string governorate);
		if (mood == 0)
		{
			auto itt = umap.find(nationalId);
			if (itt == umap.end())
			{
				User u(nationalId, "12345678", name, age, "Male", "Egypt", governorate);
				Add(u);
			}
		}
		else
		{

			User u(nationalId, "12345678", name, age, "Male", "Egypt", governorate);
			waitingList.push(u);
		}

		
	}
	fstream file;
	// opens an existing csv file or creates a new file.
	file.open("nationalId.txt", ios::out | ios::trunc);
	for (auto i : nationalIdvector)
	{
		//cout << "a\n";
		file << i << endl;
	}
	file.close();


	
}


//bool System::CheckAdmin(string nationalId)
//{
//	auto i = umap.find(nationalId);
//	if (i != umap.end())
//	{
//		if (i->second.GetAdmin() == true)
//		{
//			return true;
//		}
//		else
//		{
//			return false;
//		}
//	}
//	else
//	{
//		return false;
//	}
//}

